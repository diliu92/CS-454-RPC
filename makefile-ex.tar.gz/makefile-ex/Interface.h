#ifdef __cplusplus
extern "C" {
#endif

extern int sum(int a, int b);

#ifdef __cplusplus
}
#endif

