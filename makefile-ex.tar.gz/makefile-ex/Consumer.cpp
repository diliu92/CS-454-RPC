#include "Interface.h"
#include <stdio.h>

int main( int argc, const char* argv[] ) {
	printf("sum(%d, %d) = %d\n", 1, 2, sum(1,2));
}
